
const faqs = [
  { question: "What is your return policy?", answer: "Our return policy lasts 30 days..." },
  { question: "How long does shipping take?", answer: "Shipping typically takes 5-7 days." },
  { question: "Where are you located?", answer: "We are based in New York, USA." },
  { question: "How do I track my order?", answer: "Tracking details are sent to your email." }
];

const accordion = document.getElementById('accordion');

faqs.forEach(({ question, answer }) => {
  const item = document.createElement('div');
  item.className = 'faq-item';
  item.innerHTML = \`
    <div class="faq-question">\${question}</div>
    <div class="faq-answer">\${answer}</div>
  \`;
  item.querySelector('.faq-question').addEventListener('click', () => {
    const ans = item.querySelector('.faq-answer');
    const isVisible = ans.style.display === 'block';
    document.querySelectorAll('.faq-answer').forEach(a => a.style.display = 'none');
    ans.style.display = isVisible ? 'none' : 'block';
  });
  accordion.appendChild(item);
});

document.getElementById('styleSelector').addEventListener('change', e => {
  document.body.setAttribute('data-style', e.target.value);
});
