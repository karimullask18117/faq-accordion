document.querySelectorAll('.accordion-question').forEach(btn => {
  btn.addEventListener('click', () => {
    const answer = btn.nextElementSibling;
    const span = btn.querySelector('span');
    const isOpen = answer.style.display === 'block';

    document.querySelectorAll('.accordion-answer').forEach(a => a.style.display = 'none');
    document.querySelectorAll('.accordion-question span').forEach(s => s.textContent = '+');

    if (!isOpen) {
      answer.style.display = 'block';
      span.textContent = '-';
    }
  });
});

const toggleBtn = document.getElementById('toggle-mode');
toggleBtn.addEventListener('click', () => {
  document.body.classList.toggle('dark');
});